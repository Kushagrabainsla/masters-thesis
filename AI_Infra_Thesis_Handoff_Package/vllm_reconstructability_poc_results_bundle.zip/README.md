# Reconstructability-Aware vLLM POC

This is a **falsification POC**, not a finished vLLM feature. It is pinned to the exact vLLM commit used by the prior hybrid-state gap harness:

`e0705731be04aac90838f318fcdae15c56a53080`

## Research question

Can one group-level semantic contract — `required | reconstructable | ephemeral` — explain both:

- **Experiment A:** an ephemeral/missing state should not veto an otherwise reusable expensive prefix; and
- **Experiment B:** a reconstructable state may lag behind a required state, allowing the required prefix to be preserved while only the missing state catches up?

The POC deliberately does **not** alter vLLM's default cache-hit path. It adds an alternative `find_reconstructable_cache_plan()` method so we can test the abstraction without pretending it is production-ready.

## What the patch changes

1. Adds `KVStateReuseMode` to `KVCacheGroupSpec` with default `REQUIRED`, preserving existing semantics.
2. Adds a generic `plan_reconstructable_prefix()` helper.
3. Adds `HybridKVCacheCoordinator.find_reconstructable_cache_plan()` which uses vLLM's real per-group lookup and then applies the semantic plan.
4. Adds no model names and no Mamba/DSpark/EAGLE-specific branches to the new policy.

## Run using your existing vLLM checkout

Use the same Python environment and the same vLLM checkout from the previous gap harness.

```bash
cd reconstructability_aware_vllm_poc
source /path/to/vllm_hybrid_state_gap_harness/.venv/bin/activate
python -m pip install -r requirements.txt
python run_all.py --vllm-dir /path/to/vllm_hybrid_state_gap_harness/vendor/vllm
```

The runner requires a **clean** checkout at the exact pinned commit. If the prior harness did not modify the checkout, this should work directly.

If you no longer have that checkout, create a fresh one:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
./bootstrap.sh vendor/vllm
# Install/build vLLM CPU dependencies as you did for the prior harness if needed.
python run_all.py --vllm-dir vendor/vllm
```

## Output

Upload this file back to ChatGPT:

`vllm_reconstructability_poc_results_bundle.zip`

The bundle includes the exact git diff (including the new helper file), compile/test logs, an architecture-neutrality scan, and machine-readable A/B results.

To undo the source changes after the run:

```bash
./restore.sh /path/to/vllm
```

## Decision gate

- **GO:** A and B both pass using the same generic contract. Next: wire one real reconstruction path and measure TTFT/recompute on NVIDIA.
- **PIVOT:** A passes, B fails. Narrow to reconstructability-aware prefix reuse.
- **KILL:** A fails or the abstraction requires architecture/model-specific branches.

Passing here is **not** proof of a publishable result. It only establishes that the same semantic primitive can express both opportunities in current vLLM code.

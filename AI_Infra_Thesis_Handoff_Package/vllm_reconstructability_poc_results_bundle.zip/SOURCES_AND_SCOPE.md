# Sources and scope

## Source-pinned vLLM evidence

The POC targets commit `e0705731be04aac90838f318fcdae15c56a53080`, the same commit returned by the prior user-run harness.

At that commit:

- `HybridKVCacheCoordinator.find_longest_cache_hit()` reconciles heterogeneous cache groups by repeatedly shrinking to a prefix accepted by all participating groups.
- `find_longest_cache_hit_per_group()` already exposes independent per-group hit lengths, which gives this POC a minimal extension point.
- `KVCacheGroupSpec` already contains group-level properties such as `is_eagle_group`, `enable_kv_transfer`, and `role`; this POC tests whether reuse/reconstruction semantics belong at the same group boundary.

## What this POC does not claim

- It does not demonstrate NVIDIA speedup.
- It does not implement Mamba catch-up kernels, DSpark regeneration, or connector recovery.
- It does not prove all hybrid states are reconstructable.
- It does not claim `KVStateReuseMode` is the final API.
- It does not change vLLM's default cache-hit behavior.

The purpose is to answer one narrower question: **can the same architecture-agnostic semantic distinction express both ephemeral-state prefix reuse and partial-state recovery?**

# vLLM Hybrid-State Research Gap Harness

This suite is a falsification harness for the thesis direction:

> Can a typed model-state abstraction make allocation, prefix reuse, transfer, tiering, and recovery compositional across heterogeneous LLM state classes?

It is intentionally narrower than the previous GPU screening suites. It targets the **current vLLM source tree** and asks what is already solved versus what still breaks or remains special-cased.

## What it measures

The harness has four evidence layers:

1. **Current upstream tests** — runs vLLM CPU tests that already exercise hybrid/multi-group prefix caching.
2. **Runtime composability probe** — directly constructs current `KVCacheConfig` / `KVCacheManager` combinations on CPU and records which compositions initialize successfully or fail.
3. **Source capability probe** — scans the checked-out vLLM commit for concrete restrictions/TODOs around hybrid cache groups, DCP, KV transfer, retention, speculative decoding, and group sizing.
4. **Typed-state contract probe** — a small independent prototype that checks whether the unresolved scenarios can be expressed by one generic state contract without architecture names or special-case branches. This is only an abstraction feasibility test, not performance evidence.

The suite does **not** claim that a source restriction is automatically a publishable research gap. The returned bundle is meant to be reviewed against current papers/issues after the run.

## Why this is better than another Mac GPU benchmark

The open question is no longer whether hybrid state sizes differ. That is already established. The question is whether current serving runtimes can compose features correctly across heterogeneous state classes. Those code paths can be tested on CPU/macOS without pretending an M4 is an H100.

## Requirements

- Apple Silicon Mac (or Linux CPU machine)
- Xcode Command Line Tools on macOS
- `git`
- `uv`
- Internet access for cloning vLLM and installing dependencies

Install `uv` on macOS if needed:

```bash
brew install uv
```

vLLM currently supports Python 3.10–3.13, so this harness creates a **Python 3.12** environment even if your normal Python is 3.14.

## Run

### 1. Bootstrap a current vLLM checkout

```bash
bash bootstrap.sh
```

This clones `vllm-project/vllm` into `vendor/vllm`, records the exact git commit, creates `.venv` with Python 3.12, installs the vLLM CPU development build, and installs pytest.

The vLLM macOS build is experimental and may take several minutes because it compiles CPU components.

### 2. Run the research harness

```bash
source .venv/bin/activate
python run_all.py
```

If bootstrap already succeeded, do **not** use your earlier PyTorch 3.14 environment for this suite.

### Output

At the end you should get:

```text
vllm_hybrid_state_gap_results_bundle.zip
```

Upload that ZIP back to ChatGPT.

## What the bundle contains

- exact vLLM git SHA
- platform and Python information
- upstream hybrid-test output
- runtime composability matrix
- source capability matrix with matched file/line evidence
- typed-state contract feasibility output
- failures and skipped checks

## How we will interpret it

Possible outcomes:

- **KILL typed-state thesis**: current vLLM already composes the important features across arbitrary state classes, and remaining issues are local bugs/engineering cleanup.
- **PIVOT**: one subsystem (for example KV transfer or retention) is the real unresolved primitive; the broad typed-state thesis is too wide.
- **GO to prototype**: multiple independent subsystems fail for the same missing state-semantic contract, and a generic contract removes those failures without per-model special cases.

No GO decision should be made from this harness alone; a surviving idea still needs a real serving/inference evaluation later.

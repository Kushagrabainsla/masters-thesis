#!/usr/bin/env python3
"""Scan the exact checked-out vLLM source for hybrid-state capability boundaries.

This intentionally reports source evidence rather than guessing from docs. The
patterns are conservative and every hit includes path + line number + snippet.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "source_capabilities.json"

CHECKS = [
    {
        "id": "multigroup_fixed_point_prefix",
        "paths": ["vllm/v1/core/kv_cache_coordinator.py"],
        "patterns": [r"fixed-point algorithm", r"multiple kv cache types"],
        "meaning": "Current coordinator has explicit multi-group hybrid prefix reconciliation.",
    },
    {
        "id": "dcp_hybrid_type_restriction",
        "paths": ["vllm/v1/core/kv_cache_coordinator.py"],
        "patterns": [r"DCP with hybrid KV cache layouts only supports", r"FullAttentionSpec, MambaSpec"],
        "meaning": "DCP composability may still be restricted to selected state classes.",
    },
    {
        "id": "group_split_heuristic",
        "paths": ["vllm/v1/core/kv_cache_utils.py"],
        "patterns": [r"min_num_layers", r"group_size\s*=", r"padding"],
        "meaning": "Looks for heuristic grouping/padding logic implicated by irregular layer ratios.",
    },
    {
        "id": "global_retention_policy",
        "paths": ["vllm/v1/core/kv_cache_coordinator.py", "vllm/config/cache.py"],
        "patterns": [r"prefix_cache_retention_interval", r"retention_interval"],
        "meaning": "Looks for whether retention is represented as one coordinator/config scalar rather than a per-state policy.",
    },
    {
        "id": "hma_connector_gate",
        "paths": ["vllm/config/vllm.py", "vllm/distributed/kv_transfer"],
        "patterns": [r"SupportsHMA", r"supports_hma", r"support HMA", r"TODO.*HMA"],
        "meaning": "Hybrid memory allocation must compose with KV transfer connectors; markers/TODOs reveal boundary state.",
    },
    {
        "id": "single_group_connector_assumption",
        "paths": ["vllm/distributed/kv_transfer", "vllm/v1/simple_kv_offload"],
        "patterns": [r"block_ids\[0\]", r"group_idx", r"per-group"],
        "meaning": "Searches transfer/offload code for single-group assumptions versus per-group handling.",
    },
    {
        "id": "eagle_complex_hybrid_coverage",
        "paths": ["tests/v1/core/test_prefix_caching.py"],
        "patterns": [r"More complex hybrid models with EAGLE", r"EAGLE", r"3g-"],
        "meaning": "Checks current upstream test coverage for speculative decoding with complex hybrid state.",
    },
    {
        "id": "typed_spec_surface",
        "paths": ["vllm/v1/kv_cache_interface.py"],
        "patterns": [r"class KVCacheSpec", r"class MambaSpec", r"class SlidingWindowSpec", r"class KVCacheSpecKind"],
        "meaning": "Confirms vLLM already has a typed cache-spec abstraction; a thesis cannot claim typed specs themselves as novel.",
    },
    {
        "id": "offload_supported_kinds",
        "paths": ["vllm/v1/simple_kv_offload/manager.py"],
        "patterns": [r"FullAttentionSpec", r"MambaSpec", r"SlidingWindowSpec"],
        "meaning": "Checks whether offload behavior dispatches explicitly on a finite set of state types.",
    },
]


def iter_files(base: Path, rel: str):
    p = base / rel
    if p.is_file():
        yield p
    elif p.is_dir():
        yield from p.rglob("*.py")


def find_hits(base: Path, rel_paths: list[str], patterns: list[str]):
    hits = []
    for rel in rel_paths:
        for p in iter_files(base, rel):
            try:
                lines = p.read_text(errors="replace").splitlines()
            except Exception:
                continue
            for lineno, line in enumerate(lines, 1):
                for pattern in patterns:
                    if re.search(pattern, line, flags=re.I):
                        hits.append(
                            {
                                "path": str(p.relative_to(base)),
                                "line": lineno,
                                "pattern": pattern,
                                "snippet": line.strip()[:300],
                            }
                        )
    # Dedupe same line/pattern-ish and cap noisy searches.
    seen = set()
    out = []
    for h in hits:
        k = (h["path"], h["line"], h["snippet"])
        if k in seen:
            continue
        seen.add(k)
        out.append(h)
        if len(out) >= 40:
            break
    return out


def main():
    if len(sys.argv) != 2:
        print("usage: source_capability_probe.py /path/to/vllm", file=sys.stderr)
        raise SystemExit(2)
    base = Path(sys.argv[1]).resolve()
    if not (base / "vllm").exists():
        raise SystemExit(f"not a vLLM source tree: {base}")

    results = []
    for check in CHECKS:
        hits = find_hits(base, check["paths"], check["patterns"])
        results.append(
            {
                "id": check["id"],
                "meaning": check["meaning"],
                "hit_count": len(hits),
                "hits": hits,
            }
        )

    output = {
        "probe": "source_capability_matrix",
        "scope": "Pattern evidence from the exact checked-out vLLM commit. A hit is evidence of code shape/restriction, not proof of a research gap.",
        "checks": results,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()

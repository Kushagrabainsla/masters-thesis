#!/usr/bin/env python3
"""Runtime construction probes against the installed current vLLM code.

These are intentionally manager-level / CPU-only. They ask which combinations
of heterogeneous cache specs the current coordinator accepts, not whether GPU
kernels are fast or correct.
"""
from __future__ import annotations

import json
import math
import platform
import traceback
from pathlib import Path
from typing import Callable

import torch

from vllm.v1.core.kv_cache_manager import KVCacheManager
from vllm.v1.kv_cache_interface import (
    FullAttentionSpec,
    KVCacheConfig,
    KVCacheGroupSpec,
    MambaSpec,
    SlidingWindowSpec,
)

OUT = Path(__file__).resolve().parents[1] / "results" / "runtime_composability.json"


def full(block: int = 16):
    return FullAttentionSpec(
        block_size=block,
        num_kv_heads=1,
        head_size=8,
        dtype=torch.float32,
    )


def sw(block: int = 16, window_blocks: int = 4):
    return SlidingWindowSpec(
        block_size=block,
        num_kv_heads=1,
        head_size=8,
        dtype=torch.float32,
        sliding_window=window_blocks * block,
    )


def mamba(block: int = 16, mode: str = "none"):
    # Keep state tiny; this is an interface/composability test.
    return MambaSpec(
        block_size=block,
        shapes=((1, 8),),
        dtypes=(torch.float32,),
        mamba_cache_mode=mode,
    )


def lcm(values: list[int]) -> int:
    out = 1
    for v in values:
        out = math.lcm(out, v)
    return out


def build_manager(specs, *, dcp_world_size: int = 1, use_eagle: bool = False):
    cfg = KVCacheConfig(
        num_blocks=max(128, 32 * len(specs)),
        kv_cache_tensors=[],
        kv_cache_groups=[
            KVCacheGroupSpec([f"layer_{i}"], spec) for i, spec in enumerate(specs)
        ],
    )
    scheduler_block = lcm([int(s.block_size) for s in specs])
    hash_block = min(int(s.block_size) for s in specs)
    mgr = KVCacheManager(
        kv_cache_config=cfg,
        max_model_len=4096,
        max_in_flight_tokens=4096,
        scheduler_block_size=scheduler_block,
        hash_block_size=hash_block,
        enable_caching=True,
        use_eagle=use_eagle,
        enable_kv_cache_events=False,
        dcp_world_size=dcp_world_size,
        pcp_world_size=1,
    )
    coord = mgr.coordinator
    return {
        "coordinator_type": type(coord).__name__,
        "num_cache_groups": len(cfg.kv_cache_groups),
        "num_single_type_managers": len(getattr(coord, "single_type_managers", [])),
        "attention_spec_groups": len(getattr(coord, "attention_groups", [])),
        "enable_partial_hash_hits": bool(
            getattr(coord, "enable_partial_hash_hits", False)
        ),
        "scheduler_block_size": scheduler_block,
        "hash_block_size": hash_block,
    }


def run_case(name: str, fn: Callable[[], dict], expectation: str):
    try:
        details = fn()
        return {
            "name": name,
            "status": "accepted",
            "expectation": expectation,
            "details": details,
        }
    except Exception as exc:  # probe: record exact current behavior
        return {
            "name": name,
            "status": "rejected",
            "expectation": expectation,
            "exception_type": type(exc).__name__,
            "exception": str(exc),
            "trace_tail": traceback.format_exc().splitlines()[-8:],
        }


def main():
    cases = [
        (
            "two_groups_full_plus_sliding",
            lambda: build_manager([full(), sw()]),
            "baseline hybrid should be supported",
        ),
        (
            "three_groups_full_sliding_mamba",
            lambda: build_manager([full(), sw(), mamba()]),
            "tests 3 heterogeneous state classes",
        ),
        (
            "four_groups_full_two_sliding_mamba",
            lambda: build_manager([full(), sw(window_blocks=2), sw(window_blocks=8), mamba()]),
            "tests >3 groups and same-kind groups with different semantics",
        ),
        (
            "no_full_sliding_plus_mamba",
            lambda: build_manager([sw(), mamba()]),
            "tests hybrid coordinator without full attention reference group",
        ),
        (
            "mixed_block_sizes_full16_mamba64",
            lambda: build_manager([full(16), mamba(64, mode="align")]),
            "tests different allocation/hash granularities",
        ),
        (
            "dcp2_full_plus_mamba",
            lambda: build_manager([full(), mamba()], dcp_world_size=2),
            "current code explicitly special-cases full+mamba under DCP",
        ),
        (
            "dcp2_full_plus_sliding",
            lambda: build_manager([full(), sw()], dcp_world_size=2),
            "tests whether DCP composes with another hybrid state class",
        ),
        (
            "eagle_three_groups",
            lambda: build_manager([full(), sw(), mamba()], use_eagle=True),
            "construction-only probe; correctness requires upstream tests",
        ),
    ]

    result = {
        "probe": "runtime_composability",
        "scope": (
            "CPU manager construction only. Accepted means the current vLLM "
            "manager/coordinator can initialize the composition; it does not prove "
            "GPU execution or end-to-end correctness."
        ),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cases": [run_case(*c) for c in cases],
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

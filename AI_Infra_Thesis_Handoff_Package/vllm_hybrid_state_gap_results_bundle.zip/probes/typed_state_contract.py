#!/usr/bin/env python3
"""Abstraction-feasibility probe for a generic heterogeneous-state contract.

This is intentionally NOT a performance benchmark. It tests whether the
feature combinations currently showing friction can be represented without
branching on architecture/state names in the coordinator policy.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "results" / "typed_state_contract.json"


@dataclass(frozen=True)
class StateSpec:
    name: str
    block_tokens: int
    bytes_per_block: int
    prefix_cacheable: bool
    retention_tokens: int | None
    transfer_capable: bool
    sharding_mode: str  # "shard", "replicate", "local"
    hit_semantics: str  # "dense", "window", "checkpoint", "ephemeral"
    recovery_mode: str  # "transfer", "recompute", "checkpoint"
    speculative_role: str = "target"  # target, draft, scratch


def reconcile_prefix(candidate: int, specs: list[StateSpec], hits: dict[str, int]) -> int:
    """Generic fixed-point prefix reconciliation driven by state semantics."""
    hit = candidate
    changed = True
    while changed:
        changed = False
        for spec in specs:
            if not spec.prefix_cacheable or spec.hit_semantics == "ephemeral":
                continue
            local = min(hit, hits.get(spec.name, 0))
            if spec.hit_semantics == "window" and spec.retention_tokens:
                # A windowed state can validate a boundary if its retained tail exists.
                local = min(hit, hits.get(spec.name, 0))
            elif spec.hit_semantics == "checkpoint" and spec.retention_tokens:
                local -= local % spec.retention_tokens
            if local < hit:
                hit = local
                changed = True
    return hit


def choose_transfer(spec: StateSpec, external_available: bool) -> str:
    if external_available and spec.transfer_capable and spec.recovery_mode == "transfer":
        return "transfer"
    return spec.recovery_mode if spec.recovery_mode != "transfer" else "recompute"


def placement_key(spec: StateSpec) -> tuple:
    # Generic grouping: no state-name/type branch.
    return (
        spec.block_tokens,
        spec.bytes_per_block,
        spec.sharding_mode,
        spec.hit_semantics,
        spec.prefix_cacheable,
    )


def scenario(name, specs, hits, candidate, external=True):
    return {
        "name": name,
        "num_states": len(specs),
        "reconciled_prefix": reconcile_prefix(candidate, specs, hits),
        "placement_groups": len({placement_key(s) for s in specs}),
        "transfer_plan": {s.name: choose_transfer(s, external) for s in specs},
        "per_state_retention": {s.name: s.retention_tokens for s in specs},
        "sharding": {s.name: s.sharding_mode for s in specs},
    }


def main():
    full = StateSpec("full", 16, 4096, True, None, True, "shard", "dense", "transfer")
    sliding = StateSpec("sliding", 16, 4096, True, 2048, True, "local", "window", "transfer")
    mamba = StateSpec("mamba", 512, 65536, True, 512, True, "replicate", "checkpoint", "transfer")
    draft = StateSpec("draft", 64, 2048, False, 512, False, "local", "ephemeral", "recompute", "draft")
    scratch = StateSpec("scratch", 1, 1024, False, None, False, "local", "ephemeral", "recompute", "scratch")

    scenarios = [
        scenario(
            "three_state_prefix",
            [full, sliding, mamba],
            {"full": 4096, "sliding": 3584, "mamba": 3072},
            4096,
        ),
        scenario(
            "draft_should_not_veto_target_prefix",
            [full, sliding, draft],
            {"full": 4096, "sliding": 4096, "draft": 0},
            4096,
        ),
        scenario(
            "hybrid_transfer_fallback",
            [full, sliding, mamba],
            {"full": 2048, "sliding": 2048, "mamba": 1536},
            2048,
            external=False,
        ),
        scenario(
            "five_state_model",
            [full, sliding, mamba, draft, scratch],
            {"full": 8192, "sliding": 7680, "mamba": 7168, "draft": 0, "scratch": 0},
            8192,
        ),
    ]

    output = {
        "probe": "typed_state_contract_feasibility",
        "scope": (
            "Pure-Python abstraction test only. Success means one generic contract can "
            "represent the scenarios without architecture-name branches; it is not evidence "
            "that integrating such a contract into vLLM improves performance or correctness."
        ),
        "contract_fields": [f.name for f in StateSpec.__dataclass_fields__.values()],
        "scenarios": scenarios,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(output, indent=2))
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()

# Sources and scope

This harness was designed against vLLM `main` as observed on 2026-09-16, but it deliberately clones current `main` at run time and records the exact commit SHA.

## Current upstream evidence that changed the research question

- vLLM Hybrid KV Cache Manager design: https://docs.vllm.ai/en/latest/design/hybrid_kv_cache_manager/
- Current `HybridKVCacheCoordinator`: https://github.com/vllm-project/vllm/blob/main/vllm/v1/core/kv_cache_coordinator.py
- Current `KVCacheSpec` interface: https://github.com/vllm-project/vllm/blob/main/vllm/v1/kv_cache_interface.py
- Current upstream hybrid prefix tests: https://github.com/vllm-project/vllm/blob/main/tests/v1/core/test_prefix_caching.py

Important update: current `HybridKVCacheCoordinator` already reconciles multiple heterogeneous groups with a fixed-point algorithm. Therefore **"support 3+ cache groups" is not a defensible thesis contribution by itself**.

## Fresh capability-boundary evidence

- Hybrid KV transfer / HMA integration issue #49537:
  https://github.com/vllm-project/vllm/issues/49537
- Per-group prefix retention RFC #54661:
  https://github.com/vllm-project/vllm/issues/54661
- FP8 + Mamba/GDN page-pinning RFC #55196:
  https://github.com/vllm-project/vllm/issues/55196
- Hybrid Mamba block-size correctness bug #55600:
  https://github.com/vllm-project/vllm/issues/55600
- Complex EAGLE/MTP + 3+ group coverage issue #51771:
  https://github.com/vllm-project/vllm/issues/51771
- Irregular group splitting issue #54106:
  https://github.com/vllm-project/vllm/issues/54106
- Hybrid prefix cache draft-state veto issue #48455:
  https://github.com/vllm-project/vllm/issues/48455
- Fine-grained hybrid prefix-hit issue #53786:
  https://github.com/vllm-project/vllm/issues/53786

## Surviving hypothesis

The research question being screened is now:

> Are allocation, prefix reuse, retention, transfer/offload, speculative state, sharding, and recovery still coupled through incompatible per-feature assumptions for heterogeneous model state, such that a more explicit state-semantic contract could make these features compositional?

This is **not** the claim that vLLM lacks typed specs. It already has `KVCacheSpec` subclasses and specialized managers. The possible gap is whether the semantic contract is rich and uniform enough across independent runtime subsystems.

## What this harness cannot prove

- It does not measure H100/B200 throughput or memory bandwidth.
- It does not prove a new abstraction is faster.
- It does not prove every open issue shares one root cause.
- It does not substitute for a prototype integrated into a real serving engine.

Its purpose is to decide whether the broad typed-state thesis should be killed, narrowed, or advanced to an integration prototype.

from vllm.v1.core.consistent_state_planner_poc import (
    ActionKind,
    CostProfile,
    StateGroup,
    StateMode,
    plan_common_boundary,
    plan_fixed_always_load,
    plan_fixed_no_external_load,
    plan_min_cost,
)

PROFILE = CostProfile(
    name="balanced",
    transfer_scale=0.8,
    selective_recompute_scale=1.0,
    regenerate_scale=0.25,
    load_overhead=64.0,
)


def test_ephemeral_state_does_not_veto_required_state():
    groups = [
        StateGroup("target", StateMode.REQUIRED, resident_tokens=65536),
        StateGroup("scratch", StateMode.EPHEMERAL, resident_tokens=0, compute_weight=0.05),
    ]
    strict = plan_common_boundary(groups, 65536, PROFILE)
    planned = plan_min_cost(groups, 65536, PROFILE)
    assert planned.total_cost < strict.total_cost
    assert any(a.kind is ActionKind.REGENERATE for a in planned.actions)
    assert not any(a.kind is ActionKind.FULL_RECOMPUTE for a in planned.actions)


def test_external_checkpoint_vs_direct_rebuild_is_cost_sensitive():
    groups = [
        StateGroup("target", StateMode.REQUIRED, resident_tokens=65536),
        StateGroup(
            "aux", StateMode.RECONSTRUCTABLE,
            resident_tokens=8192,
            external_tokens=32768,
            compute_weight=0.22,
            transfer_weight=0.08,
        ),
    ]
    cheap_load = CostProfile("cheap_load", 0.1, 1.0, 0.25, 8.0)
    expensive_load = CostProfile("expensive_load", 4.0, 0.7, 0.25, 512.0)
    p1 = plan_min_cost(groups, 65536, cheap_load)
    p2 = plan_min_cost(groups, 65536, expensive_load)
    assert any(a.kind is ActionKind.LOAD for a in p1.actions)
    assert not any(a.kind is ActionKind.LOAD for a in p2.actions)


def test_three_state_case_can_mix_load_and_rebuild_actions():
    groups = [
        StateGroup("target", StateMode.REQUIRED, resident_tokens=65536),
        StateGroup("window", StateMode.RECONSTRUCTABLE, 32768, 49152, 0.15, 0.16),
        StateGroup("recurrent", StateMode.RECONSTRUCTABLE, 8192, 32768, 0.24, 0.05),
        StateGroup("scratch", StateMode.EPHEMERAL, 0, 0, 0.04, 0.0),
    ]
    plan = plan_min_cost(groups, 65536, PROFILE)
    kinds = {a.kind for a in plan.actions}
    assert ActionKind.REGENERATE in kinds
    assert ActionKind.SELECTIVE_REBUILD in kinds


def test_min_cost_never_worse_than_fixed_fallbacks():
    groups = [
        StateGroup("target", StateMode.REQUIRED, resident_tokens=32768, external_tokens=65536, transfer_weight=0.4),
        StateGroup("recurrent", StateMode.RECONSTRUCTABLE, 8192, 32768, 0.2, 0.08),
    ]
    planner = plan_min_cost(groups, 65536, PROFILE)
    fixed = [
        plan_common_boundary(groups, 65536, PROFILE),
        plan_fixed_no_external_load(groups, 65536, PROFILE),
        plan_fixed_always_load(groups, 65536, PROFILE),
    ]
    assert planner.total_cost <= min(x.total_cost for x in fixed) + 1e-9


def test_planner_code_is_architecture_neutral_by_construction():
    groups = [
        StateGroup("alpha", StateMode.REQUIRED, 4096),
        StateGroup("beta", StateMode.RECONSTRUCTABLE, 1024, 2048, 0.2, 0.1),
        StateGroup("gamma", StateMode.EPHEMERAL, 0, 0, 0.05, 0.0),
    ]
    plan = plan_min_cost(groups, 4096, PROFILE)
    assert plan.valid

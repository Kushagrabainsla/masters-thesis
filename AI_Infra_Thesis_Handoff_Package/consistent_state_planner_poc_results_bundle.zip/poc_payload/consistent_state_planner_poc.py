from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable


class StateMode(str, Enum):
    REQUIRED = "required"
    RECONSTRUCTABLE = "reconstructable"
    EPHEMERAL = "ephemeral"


class ActionKind(str, Enum):
    REUSE = "reuse"
    LOAD = "load"
    FULL_RECOMPUTE = "full_recompute"
    SELECTIVE_REBUILD = "selective_rebuild"
    REGENERATE = "regenerate"


@dataclass(frozen=True)
class StateGroup:
    """Architecture-neutral state description for the POC.

    Costs are deliberately expressed in normalized full-model-token-equivalent
    units. They are not GPU-time predictions. A later NVIDIA POC must replace
    these ratios with measured costs.
    """

    name: str
    mode: StateMode
    resident_tokens: int
    external_tokens: int = 0
    compute_weight: float = 1.0
    transfer_weight: float = 0.25

    def __post_init__(self) -> None:
        if self.resident_tokens < 0 or self.external_tokens < 0:
            raise ValueError("token counts must be non-negative")
        if self.compute_weight < 0 or self.transfer_weight < 0:
            raise ValueError("cost weights must be non-negative")


@dataclass(frozen=True)
class CostProfile:
    name: str
    transfer_scale: float
    selective_recompute_scale: float
    regenerate_scale: float
    load_overhead: float = 0.0
    full_recompute_scale: float = 1.0


@dataclass(frozen=True)
class Action:
    group: str
    kind: ActionKind
    start_tokens: int
    target_tokens: int
    cost: float
    detail: str = ""


@dataclass
class Plan:
    target_tokens: int
    actions: list[Action] = field(default_factory=list)
    total_cost: float = 0.0
    valid: bool = True
    note: str = ""

    @property
    def signature(self) -> str:
        return "+".join(
            f"{a.group}:{a.kind.value}" for a in sorted(self.actions, key=lambda x: x.group)
        )


def _load_cost(group: StateGroup, from_tokens: int, to_tokens: int, profile: CostProfile) -> float:
    if to_tokens <= from_tokens:
        return 0.0
    return (
        (to_tokens - from_tokens) * group.transfer_weight * profile.transfer_scale
        + profile.load_overhead
    )


def _selective_rebuild_cost(
    group: StateGroup, from_tokens: int, to_tokens: int, profile: CostProfile
) -> float:
    if to_tokens <= from_tokens:
        return 0.0
    return (
        (to_tokens - from_tokens)
        * group.compute_weight
        * profile.selective_recompute_scale
    )


def _full_recompute_cost(from_tokens: int, to_tokens: int, profile: CostProfile) -> float:
    if to_tokens <= from_tokens:
        return 0.0
    return (to_tokens - from_tokens) * profile.full_recompute_scale


def _regenerate_cost(group: StateGroup, target_tokens: int, profile: CostProfile) -> float:
    return target_tokens * group.compute_weight * profile.regenerate_scale


def _required_group_options(
    group: StateGroup, target_tokens: int, profile: CostProfile
) -> list[tuple[float, list[Action], bool]]:
    """Return (cost, actions, full_recompute_used) options for REQUIRED state.

    If full recomputation is selected, the caller may treat other non-ephemeral
    model states as freshly produced through the target boundary.
    """
    options: list[tuple[float, list[Action], bool]] = []

    if group.resident_tokens >= target_tokens:
        options.append((
            0.0,
            [Action(group.name, ActionKind.REUSE, target_tokens, target_tokens, 0.0)],
            False,
        ))
    else:
        # Recompute from the deepest currently resident correct boundary.
        rcost = _full_recompute_cost(group.resident_tokens, target_tokens, profile)
        options.append((
            rcost,
            [Action(
                group.name,
                ActionKind.FULL_RECOMPUTE,
                group.resident_tokens,
                target_tokens,
                rcost,
                "recompute target model state from resident boundary",
            )],
            True,
        ))

    if group.external_tokens > group.resident_tokens:
        loaded_to = min(group.external_tokens, target_tokens)
        lcost = _load_cost(group, group.resident_tokens, loaded_to, profile)
        actions = [Action(
            group.name,
            ActionKind.LOAD,
            group.resident_tokens,
            loaded_to,
            lcost,
            "load externally available required state",
        )]
        if loaded_to < target_tokens:
            rcost = _full_recompute_cost(loaded_to, target_tokens, profile)
            actions.append(Action(
                group.name,
                ActionKind.FULL_RECOMPUTE,
                loaded_to,
                target_tokens,
                rcost,
                "finish required state with normal model recomputation",
            ))
            options.append((lcost + rcost, actions, True))
        else:
            options.append((lcost, actions, False))

    return options


def _reconstructable_options(
    group: StateGroup, target_tokens: int, profile: CostProfile
) -> list[tuple[float, list[Action]]]:
    if group.resident_tokens >= target_tokens:
        return [(
            0.0,
            [Action(group.name, ActionKind.REUSE, target_tokens, target_tokens, 0.0)],
        )]

    options: list[tuple[float, list[Action]]] = []

    # Rebuild directly from resident state.
    rcost = _selective_rebuild_cost(group, group.resident_tokens, target_tokens, profile)
    options.append((
        rcost,
        [Action(
            group.name,
            ActionKind.SELECTIVE_REBUILD,
            group.resident_tokens,
            target_tokens,
            rcost,
            "rebuild only this reconstructable state",
        )],
    ))

    # Load the deepest external checkpoint, then rebuild only the suffix.
    if group.external_tokens > group.resident_tokens:
        loaded_to = min(group.external_tokens, target_tokens)
        lcost = _load_cost(group, group.resident_tokens, loaded_to, profile)
        actions = [Action(
            group.name,
            ActionKind.LOAD,
            group.resident_tokens,
            loaded_to,
            lcost,
            "load external checkpoint/state",
        )]
        total = lcost
        if loaded_to < target_tokens:
            suffix = _selective_rebuild_cost(group, loaded_to, target_tokens, profile)
            total += suffix
            actions.append(Action(
                group.name,
                ActionKind.SELECTIVE_REBUILD,
                loaded_to,
                target_tokens,
                suffix,
                "rebuild only missing suffix after external checkpoint",
            ))
        options.append((total, actions))

    return options


def plan_min_cost(
    groups: Iterable[StateGroup], target_tokens: int, profile: CostProfile
) -> Plan:
    groups = list(groups)
    required = [g for g in groups if g.mode is StateMode.REQUIRED]
    if not required:
        return Plan(target_tokens, valid=False, note="at least one REQUIRED state group is needed")

    # The POC currently supports a single REQUIRED anchor. This is a deliberate
    # scope restriction, not an architecture restriction. The next prototype
    # can generalize to multiple anchors if the policy-space test survives.
    if len(required) != 1:
        return Plan(target_tokens, valid=False, note="POC supports one REQUIRED anchor")

    anchor = required[0]
    best: Plan | None = None

    for required_cost, required_actions, full_recompute_used in _required_group_options(
        anchor, target_tokens, profile
    ):
        actions = list(required_actions)
        total = required_cost

        for group in groups:
            if group is anchor:
                continue
            if group.mode is StateMode.EPHEMERAL:
                ecost = _regenerate_cost(group, target_tokens, profile)
                actions.append(Action(
                    group.name,
                    ActionKind.REGENERATE,
                    0,
                    target_tokens,
                    ecost,
                    "ephemeral state regenerated from preserved/produced target state",
                ))
                total += ecost
                continue

            if full_recompute_used:
                # Normal target-model recomputation is assumed to reproduce all
                # non-ephemeral model states along that recomputed suffix.
                actions.append(Action(
                    group.name,
                    ActionKind.REUSE,
                    target_tokens,
                    target_tokens,
                    0.0,
                    "produced as a side effect of full target-model recomputation",
                ))
                continue

            options = _reconstructable_options(group, target_tokens, profile)
            if not options:
                return Plan(target_tokens, valid=False, note=f"no valid action for {group.name}")
            gcost, gactions = min(options, key=lambda x: x[0])
            total += gcost
            actions.extend(gactions)

        candidate = Plan(target_tokens, actions=actions, total_cost=total)
        if best is None or candidate.total_cost < best.total_cost:
            best = candidate

    assert best is not None
    return best


def plan_common_boundary(
    groups: Iterable[StateGroup], target_tokens: int, profile: CostProfile
) -> Plan:
    """Conservative all-groups-must-match baseline.

    Ephemeral state participates in the shared boundary on purpose: this models
    the overly strict behavior motivating the original prefix-veto case.
    """
    groups = list(groups)
    boundary = min(min(g.resident_tokens, target_tokens) for g in groups)
    cost = _full_recompute_cost(boundary, target_tokens, profile)
    actions = [Action(
        "target_model",
        ActionKind.FULL_RECOMPUTE,
        boundary,
        target_tokens,
        cost,
        "shared prefix boundary forces normal model recomputation",
    )]
    for group in groups:
        if group.mode is StateMode.EPHEMERAL:
            ecost = _regenerate_cost(group, target_tokens, profile)
            cost += ecost
            actions.append(Action(
                group.name, ActionKind.REGENERATE, 0, target_tokens, ecost
            ))
    return Plan(target_tokens, actions=actions, total_cost=cost)


def plan_fixed_no_external_load(
    groups: Iterable[StateGroup], target_tokens: int, profile: CostProfile
) -> Plan:
    """Simple fallback: preserve required state, never load external state."""
    groups = list(groups)
    anchor = next((g for g in groups if g.mode is StateMode.REQUIRED), None)
    if anchor is None:
        return Plan(target_tokens, valid=False, note="missing REQUIRED anchor")

    if anchor.resident_tokens < target_tokens:
        cost = _full_recompute_cost(anchor.resident_tokens, target_tokens, profile)
        actions = [Action(
            anchor.name,
            ActionKind.FULL_RECOMPUTE,
            anchor.resident_tokens,
            target_tokens,
            cost,
        )]
        for group in groups:
            if group.mode is StateMode.EPHEMERAL:
                ecost = _regenerate_cost(group, target_tokens, profile)
                actions.append(Action(group.name, ActionKind.REGENERATE, 0, target_tokens, ecost))
                cost += ecost
            elif group is not anchor:
                actions.append(Action(group.name, ActionKind.REUSE, target_tokens, target_tokens, 0.0))
        return Plan(target_tokens, actions=actions, total_cost=cost)

    cost = 0.0
    actions = [Action(anchor.name, ActionKind.REUSE, target_tokens, target_tokens, 0.0)]
    for group in groups:
        if group is anchor:
            continue
        if group.mode is StateMode.EPHEMERAL:
            ecost = _regenerate_cost(group, target_tokens, profile)
            cost += ecost
            actions.append(Action(group.name, ActionKind.REGENERATE, 0, target_tokens, ecost))
        else:
            rcost = _selective_rebuild_cost(group, group.resident_tokens, target_tokens, profile)
            cost += rcost
            actions.append(Action(
                group.name,
                ActionKind.SELECTIVE_REBUILD,
                group.resident_tokens,
                target_tokens,
                rcost,
            ))
    return Plan(target_tokens, actions=actions, total_cost=cost)


def plan_fixed_always_load(
    groups: Iterable[StateGroup], target_tokens: int, profile: CostProfile
) -> Plan:
    """Simple fallback: load deepest external state whenever it extends residency."""
    groups = list(groups)
    anchor = next((g for g in groups if g.mode is StateMode.REQUIRED), None)
    if anchor is None:
        return Plan(target_tokens, valid=False, note="missing REQUIRED anchor")

    actions: list[Action] = []
    cost = 0.0

    anchor_start = anchor.resident_tokens
    if anchor.external_tokens > anchor_start:
        loaded_to = min(anchor.external_tokens, target_tokens)
        lcost = _load_cost(anchor, anchor_start, loaded_to, profile)
        actions.append(Action(anchor.name, ActionKind.LOAD, anchor_start, loaded_to, lcost))
        cost += lcost
        anchor_start = loaded_to

    if anchor_start < target_tokens:
        rcost = _full_recompute_cost(anchor_start, target_tokens, profile)
        actions.append(Action(anchor.name, ActionKind.FULL_RECOMPUTE, anchor_start, target_tokens, rcost))
        cost += rcost
        full_recompute = True
    else:
        actions.append(Action(anchor.name, ActionKind.REUSE, target_tokens, target_tokens, 0.0))
        full_recompute = False

    for group in groups:
        if group is anchor:
            continue
        if group.mode is StateMode.EPHEMERAL:
            ecost = _regenerate_cost(group, target_tokens, profile)
            cost += ecost
            actions.append(Action(group.name, ActionKind.REGENERATE, 0, target_tokens, ecost))
            continue
        if full_recompute:
            actions.append(Action(group.name, ActionKind.REUSE, target_tokens, target_tokens, 0.0))
            continue
        start = group.resident_tokens
        if group.external_tokens > start:
            loaded_to = min(group.external_tokens, target_tokens)
            lcost = _load_cost(group, start, loaded_to, profile)
            cost += lcost
            actions.append(Action(group.name, ActionKind.LOAD, start, loaded_to, lcost))
            start = loaded_to
        if start < target_tokens:
            rcost = _selective_rebuild_cost(group, start, target_tokens, profile)
            cost += rcost
            actions.append(Action(group.name, ActionKind.SELECTIVE_REBUILD, start, target_tokens, rcost))
        else:
            actions.append(Action(group.name, ActionKind.REUSE, target_tokens, target_tokens, 0.0))

    return Plan(target_tokens, actions=actions, total_cost=cost)

# Sources and scope

## Pinned vLLM source

The harness creates a temporary worktree at:

`e0705731be04aac90838f318fcdae15c56a53080`

This is the same commit used by the preceding vLLM gap and reconstructability POCs.

## Current evidence motivating the scenarios

### vLLM #48455 — ephemeral draft state can veto reusable target state

https://github.com/vllm-project/vllm/issues/48455

The issue describes DSpark draft state as ephemeral and not meaningfully reusable across lookup boundaries, yet its zero hit can truncate otherwise valid target-state prefix reuse. This motivates the generic `EPHEMERAL` case, but the POC does not encode DSpark/model names.

### vLLM #53041 — divergent recurrent/SWA state and full-attention KV

https://github.com/vllm-project/vllm/issues/53041

The discussion proposes preserving deeper full-attention KV while externally loading and/or selectively recomputing lagging SWA/Mamba state. It explicitly identifies the choice among local state, external state, and recomputation. This motivates the `RECONSTRUCTABLE` recovery scenarios.

### vLLM #47812 — hybrid recovery after KV load failure

https://github.com/vllm-project/vllm/issues/47812

Current load-failure recovery has had single-group assumptions on hybrid models. This supports treating recovery as a per-state-group decision rather than one global rewind.

### vLLM #55600 — state-specific geometry is correctness-critical

https://github.com/vllm-project/vllm/issues/55600

This issue shows that using a global block size for recurrent state can restore the wrong state or trigger illegal memory access. It supports the broader premise that heterogeneous state semantics cannot safely be flattened into one global cache abstraction.

### Sparse Prefix Caching for Hybrid and Recurrent LLM Serving

https://arxiv.org/abs/2605.05219

This paper already formalizes sparse recurrent checkpoints and exact suffix recomputation. Therefore this POC does **not** claim that checkpointed recurrent-state reconstruction is novel. The open question is whether a general minimum-cost planner across multiple heterogeneous state classes is useful beyond these specialized mechanisms.

## What this POC does *not* establish

- It does not measure CUDA/H100/B200 performance.
- It does not estimate real PCIe/NVLink/RDMA transfer time.
- It does not prove a general planner is novel.
- It does not execute a real Mamba/attention recovery path.
- It does not claim normalized cost units correspond to milliseconds.

Its only purpose is to determine whether the decision problem remains non-trivial under a broad cost sweep. If not, the general planner should be killed before GPU engineering.

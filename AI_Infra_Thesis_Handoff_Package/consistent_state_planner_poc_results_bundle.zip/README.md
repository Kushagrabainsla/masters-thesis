# Minimum-Cost Consistent-State Planner POC

This is the next falsification test for the **reconstructability-aware hybrid LLM state** thesis direction.

It does **not** claim to predict H100 latency. It asks a narrower question first:

> Across realistic hybrid-state availability patterns, is there a genuinely non-trivial choice among reusing, loading, selectively rebuilding, regenerating, and fully recomputing state—or does one simple fallback policy perform essentially as well everywhere?

If one fixed rule dominates, the general planner thesis should be killed before GPU implementation.

## Why this POC exists

The preceding vLLM POC showed that one architecture-neutral `required / reconstructable / ephemeral` contract can express both ephemeral-state reuse and partial-state recovery. However, those concrete mechanisms have close active upstream work. The remaining research hypothesis is the **decision problem**: choose the cheapest correct state plan when different state classes have different availability and recovery costs.

This POC therefore compares:

1. `common_boundary`: strict all-groups-must-match behavior;
2. `never_load_external`: preserve required state and selectively rebuild missing auxiliary state, never loading external state;
3. `always_load_external`: load every deeper external checkpoint/state before rebuilding any remaining suffix;
4. `min_cost_planner`: choose per state group among `reuse`, `load`, `selective_rebuild`, `regenerate`, and `full_recompute`.

The cost sweep is deliberately broad and expressed in **normalized full-model-token-equivalent units**. It is a sensitivity analysis, not a performance claim.

## Important design choice

The harness uses a temporary detached git worktree at the same vLLM commit used in the previous experiments:

`e0705731be04aac90838f318fcdae15c56a53080`

It does not modify your existing vLLM checkout, even if that checkout still contains the previous POC patch.

## Run

Activate the same Python 3.12 vLLM environment you used previously, then:

```bash
python -m pip install -r requirements.txt
python run_all.py \
  --vllm-dir ../vllm_hybrid_state_gap_harness/vendor/vllm
```

If your vLLM clone is elsewhere, pass that path instead.

At completion, upload:

`consistent_state_planner_poc_results_bundle.zip`

## What will be in the bundle

- `results/run_summary.json`
- `results/planner_summary.json`
- `results/planner_matrix.csv`
- `results/pytest.log`
- `results/architecture_neutrality.json`
- `results/source_capability_scan.json`
- `results/environment.json`
- `results/poc.patch`

## Predeclared screen

The thresholds below are heuristics, **not literature standards**.

The general-planner hypothesis gets a Mac/CPU-side `GO_TO_NVIDIA_COST_MEASUREMENT` only if most of the following hold:

- at least 3 distinct optimal plan signatures appear across the cost sweep;
- some scenarios choose mixed actions (for example, load one state while rebuilding another);
- the planner is not equivalent to the best simple fallback in >=90% of cases;
- median gain over one globally fixed simple policy is >=10%;
- p90 gain over the best simple policy for each individual row is >=5%.

A GO here means only: **the policy space is non-trivial enough to justify measuring the real costs on NVIDIA hardware.**

It does not establish end-to-end speedup.

## Scenarios

The scenarios are based on current hybrid-serving failure/recovery classes rather than arbitrary model names:

- reusable target state + ephemeral scratch/draft state;
- target KV deeper than recurrent state, with an external recurrent checkpoint;
- recurrent state missing without an external checkpoint;
- three-state mixed recovery (windowed + recurrent + ephemeral);
- externally available required state versus recomputation;
- short-context case where load overhead may dominate.

The planner implementation itself contains no architecture/model-name branches.

# Sources and scope

Current-source checks used to design this POC (September 2026):

1. Hugging Face Transformers Qwen3.5 implementation
   - https://github.com/huggingface/transformers/blob/main/src/transformers/models/qwen3_5/modeling_qwen3_5.py
   - The decoder interleaves `linear_attention` and `full_attention` layers.
   - Full attention computes Q/K/V projections before `past_key_values.update(...)`.

2. Qwen3.5 model card
   - https://huggingface.co/Qwen/Qwen3.5-0.8B-Base
   - 24 layers, layout `6 x (3 x Gated DeltaNet + 1 x Gated Attention)`, hidden size 1024.

3. Transformers cache implementation
   - https://github.com/huggingface/transformers/blob/main/src/transformers/cache_utils.py
   - Full-attention layers retain token-wise K/V; linear-attention layers retain convolution and recurrent state.

4. vLLM issue #53041, Tiered SWA/Mamba checkpointing + recompute backfill
   - https://github.com/vllm-project/vllm/issues/53041
   - Explicitly proposes keeping full-attention KV while recomputing lagging SWA/Mamba state.
   - The issue itself identifies per-layer skip/compute as the invasive technical challenge.

5. Sparse Prefix Caching for Hybrid and Recurrent LLM Serving (2026)
   - https://arxiv.org/abs/2605.05219
   - Establishes sparse recurrent checkpoints and exact suffix reconstruction as prior work.

6. vLLM RFC #55697, Application-Directed Prefix Checkpoints
   - https://github.com/vllm-project/vllm/issues/55697
   - Strong recent novelty threat for shared-prefix checkpoint placement and producer/consumer scheduling.
   - It is not the same experiment as divergent full-KV vs lagging recurrent-state recovery, but it materially narrows the thesis space.

## Exact hypothesis tested here

This POC does **not** ask whether caching or suffix replay is useful; the previous Mac experiment already established that.

It asks:

> Given a valid recurrent state at K and already-valid full-attention KV through N, how much extra computation can actually be removed while rebuilding recurrent state K..N without violating the interleaved model's hidden-state dependencies?

The POC is intentionally capable of killing the idea.

# Mac State-Selective Recovery POC

This is the next falsification experiment for the hybrid-LLM thesis direction.

## Question

When full-attention KV is valid deeper into a prefix than the recurrent/linear-attention state, is preserving that deeper KV **actually cheaper** than ordinary suffix replay once the model's inter-layer dependencies are respected?

This is deliberately stricter than the previous Mac experiment. The previous run established that Qwen3.5 has heterogeneous cache growth and that later valid boundaries save real work. This POC asks whether **divergent state boundaries** create additional savings.

## Why this is a hard question

Qwen3.5-0.8B interleaves 3 Gated DeltaNet layers with 1 full-attention layer. To rebuild a later recurrent state, hidden activations must still flow through the intervening full-attention decoder blocks. Merely having their K/V cached does not automatically give you the block output.

The POC therefore compares four paths plus a negative control:

1. `normal_suffix_replay`
   - Cache is valid only to K.
   - Run K..N normally through the hybrid model.

2. `frozen_full_kv_replay`
   - Linear/recurrent state is valid only to K.
   - Full-attention K/V is already valid through N.
   - During replay K..N, full-attention cache updates are frozen and the existing K/V is reused.
   - Q/K/V projections still execute because stock Transformers computes them before cache update.

3. `frozen_full_kv_bypass_kv_proj`
   - Same state semantics as #2.
   - Replaces the now-dead K/V projection matmuls with cheap zero-shaped outputs; the frozen cache supplies the real K/V.
   - This approximates a straightforward optimized implementation without writing a custom attention kernel.

4. `oracle_cached_full_block_outputs`
   - Stores the exact post-decoder-block hidden activations for all six full-attention blocks during the reference run.
   - During recovery, those full blocks are skipped and their cached outputs are injected.
   - This is **not deployable** as-is. It is an oracle/lower-bound probe for how much compute could be removed if extra activation state were retained.
   - The script records the activation-memory cost.

5. `naive_identity_skip_full_blocks`
   - Deliberately skips full-attention blocks without cached activations.
   - This should fail numerical equivalence. It is a negative control demonstrating the inter-layer dependency.

## What a useful result looks like

The most important comparison is:

`frozen_full_kv_bypass_kv_proj` vs `normal_suffix_replay`.

If preserving deeper K/V plus eliminating redundant K/V projection work saves very little, then the broad "rebuild only recurrent state while keeping attention KV" story is much weaker than it sounds: most suffix computation still has to run.

If the K/V-only path is weak but the activation oracle is much faster, the problem may pivot toward **which intermediate activations/state should be checkpointed**, not merely KV-vs-recurrent cache recovery.

## Run

You can use the same environment and already-downloaded Qwen weights from the previous Mac POC.

```bash
unzip mac_state_selective_recovery_poc.zip
cd mac_state_selective_recovery_poc

# Either reuse the previous environment:
source ../mac_hybrid_selective_recovery_poc/.venv/bin/activate

# Or make a fresh one:
# python3 -m venv .venv
# source .venv/bin/activate

python -m pip install -r requirements.txt
python -c "import torch; print(torch.__version__); print(torch.backends.mps.is_available())"
```

MPS must print `True`.

Run the standard screen:

```bash
python run_mac_selective.py
```

If you want a very small smoke test first:

```bash
python run_mac_selective.py --mode quick
```

Only use deep mode after standard works:

```bash
python run_mac_selective.py --mode deep
```

Do **not** set `PYTORCH_ENABLE_MPS_FALLBACK=1` unless we are debugging a hard unsupported-op failure. Hidden CPU fallback would contaminate timing.

## Output

The script creates:

```text
mac_state_selective_recovery_results_bundle.zip
```

Upload that ZIP back to ChatGPT.

Important files:

- `results/summary.json`
- `results/scenario_summary.json`
- `results/correctness.json`
- `results/measurements.csv`
- `results/oracle_activation_memory.json`
- `results/static_compute_analysis.json`
- `results/source_fingerprints.json`
- `results/failures.json`

## Decision rule

The thresholds are research heuristics, not literature standards.

- **Promising:** semantic recovery is correct, frozen K/V is unchanged, and the optimized frozen-KV path saves >=10% median time over normal suffix replay.
- **Pivot:** K/V-only savings are <10%, but the full-block activation oracle saves >=25%. The interesting primitive would then be extra checkpointed intermediate state/activations, not KV-only selective recovery.
- **Deprioritize:** both the K/V-only path and the oracle show little headroom.
- **Invalid:** numerical equivalence fails or frozen full-attention K/V changes during recovery.

## Important limitation

This is Apple MPS + Transformers eager attention. It does not establish CUDA/HBM/vLLM production performance. It is a Mac-first falsification screen for the computation dependency itself.

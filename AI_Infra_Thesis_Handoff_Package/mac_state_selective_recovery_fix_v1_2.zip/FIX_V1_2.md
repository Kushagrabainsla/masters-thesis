# v1.2 fix

The v1.1 cache-layer geometry override was insufficient because Qwen3.5 creates its full-attention mask before decoder-layer execution. v1.2 bypasses that inference during the recovery experiment by passing an explicit attention-mask mapping:

- `full_attention`: 4-D additive causal mask `[B,1,N-K,N]` for suffix queries at absolute positions `K..N-1` against frozen K/V at `0..N-1`.
- `linear_attention`: 2-D all-ones suffix padding mask `[B,N-K]`.

This is specific to the experimental recovery path and does not change the model weights or Transformers installation.

# GPU Efficiency Screening Suite V2.1 - Results

These are Mac-side empirical screens, not final NVIDIA GPU validation.

## Machine
```json
{
  "platform": "macOS-26.5.2-arm64-arm-64bit-Mach-O",
  "machine": "arm64",
  "processor": "arm",
  "python": "3.14.6 (main, Jun 10 2026, 10:03:53) [Clang 21.0.0 (clang-2100.0.123.102)]",
  "hw.model": "Mac16,12",
  "hw.memsize": "17179869184",
  "machdep.cpu.brand_string": "Apple M4",
  "torch_version": "2.14.0",
  "mps_built": true,
  "mps_available": true,
  "cuda_available": false
}
```

## Tests
| Test | Signal | Scope |
| --- | --- | --- |
| 1_activation_residency | weak_or_static | Real PyTorch forward/backward timing and sampled accelerator allocation on this machine. It does not reproduce H100 PCIe/HBM behavior. |
| 2_network_crossover | weak_or_static | Measures real MPS compute and real local socket transfer, while bandwidth/latency are intentionally shaped in software. It only screens whether communication structure has crossovers; it does not emulate NCCL or real multi-GPU TP/PP/DP. |
| 3_elastic_break_even | measurable_break_even | Measures real CPU and MPS work rates, concurrent throughput, and real host/device state-copy cost on Apple unified-memory hardware. It is a break-even experiment, not a substitute for H100/H200 measurements. |
| 4_sharing_interference | real_multi_process_interference_measured | Exploratory Apple-MPS measurement. Isolated and concurrent workloads execute in separate processes, so each owns its own MPS command context while macOS/Metal arbitrates the physical GPU. This avoids unsupported same-process concurrent encoder submission. It does not reproduce CUDA MPS/MIG/NCCL or datacenter GPU sharing. |
| 5_hybrid_allocator | use_to_check_residual_allocator_tradeoff_not_as_standalone_thesis | Measures actual accelerator allocation overhead while the size ratios are architecture-inspired. It is primarily a clutter filter: current vLLM already has a Hybrid Memory Allocator and packed layouts, so padding savings alone are not a novel thesis contribution. |

## Important
- Do not convert these signals directly into GO/KILL thesis decisions.
- Test 4 uses separate MPS processes to avoid unsupported same-process concurrent Metal command encoding.
- Upload the generated bundle back to ChatGPT for raw-distribution analysis.
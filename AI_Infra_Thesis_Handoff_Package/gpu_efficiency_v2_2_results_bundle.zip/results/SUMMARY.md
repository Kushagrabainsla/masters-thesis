# GPU Efficiency Screening Suite V2.2 - Results

Targeted follow-up after V2.1. These tests have deliberately different evidence levels.

| Test | Signal | Scope |
| --- | --- | --- |
| 1_network_overlap_crossover | crossover_observed | Real MPS compute and real loopback socket transfers. All strategies perform the same eight compute chunks and 64MiB communication; the experiment varies only communication granularity and whether communication overlaps later compute. Network bandwidth/latency are software-shaped. This is a crossover screen, not NCCL TP/PP/DP validation. |
| 2_trace_elasticity | trace_characterization_only | Uses the public Alibaba 2026 spot-GPU node/job trace. Spare capacity is derived as node inventory minus concurrent HP requested GPUs, so it is an upper-bound opportunity signal, not proof that capacity was allocatable to one elastic training job. No Mac CPU/MPS throughput is used as a proxy for heterogeneous GPUs. |
| 3_typed_state_allocator | prototype_worthwhile_if_savings_persist_in_real_vllm | The memory model is grounded in current vLLM hybrid-cache design constraints and 2026 issues, while local MPS allocations measure only allocation overhead at scaled pool sizes. Modeled savings are not a serving benchmark. The purpose is to determine whether irregular 2-type and >2-type state layouts create enough memory-pressure signal to justify a real vLLM prototype. |

## Evidence discipline
- Test 1 is a real Mac MPS + real socket crossover microbenchmark with software-shaped network conditions.
- Test 2 is a trace characterization using Alibaba's public 2026 spot-GPU trace; it is not a local hardware benchmark.
- Test 3 combines a source-grounded memory model with scaled real MPS allocation timing; modeled memory savings are not a vLLM serving result.
- Upload the bundle for interpretation before treating any result as a thesis GO/KILL decision.
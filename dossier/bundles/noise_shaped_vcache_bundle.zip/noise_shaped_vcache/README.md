# noise_shaped_vcache (I-58)

Noise-shaped (sigma-delta) quantization of the V cache along the token axis. See
`dossier/ROUTES_R-10_2026-10-07.md` and journal Section 5.14.

- `reviewer_ef_sim2.py`: the synthetic check that the R-10 reviewer (a different model, Sonnet)
  wrote. It uses iid Gaussian V and synthetic attention weights. The main session re-ran it on
  2026-10-07 and got the same output. Run it with `python3 reviewer_ef_sim2.py` (standard library
  only, about 15 s).
- The decisive test on real attention (E-27) is not written yet. Predeclare it in the journal
  before you run it.
